# Admin Will Read It

This archive contains the participant-facing application source.

The hosted challenge service remains the target. Runtime secrets, deployment configuration, and author-only materials are excluded.
