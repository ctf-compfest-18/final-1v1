# temu awk++

by kannrisha

## Description

If you don't know, this is inspired by the awk challenge series by Zafirr.
It's 1000 times easier though, as you will need to solve this in under 20 minutes :p

## Hints

- You need to leak libc from the heap.
